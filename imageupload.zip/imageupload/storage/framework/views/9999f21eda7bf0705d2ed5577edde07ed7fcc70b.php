
<?php $__env->startSection('content'); ?>
<div class="card" style="margin: 20px;">
<div class="card-header">Create New Employee</div>
<div class="card-body">
<form action="<?php echo e(url('employee')); ?>" method="post"
enctype="multipart/form-data">
<?php echo csrf_field(); ?>

<label>Name</label></br>
<input type="text" name="name" id="name" class="formcontrol"></br>
<label>Gender</label></br>
<input type="text" name="Gender" id="Gender" class="formcontrol"></br>
<label>Index</label></br>
<input type="text" name="Index" id="Index" class="formcontrol"></br>
<label>Special</label></br>
<input type="text" name="Special" id="Special" class="formcontrol"></br>
<input class="form-control" name="photo" type="file" id="photo">
<input type="submit" value="Save" class="btn btn-success"></br>
</form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employees.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\016\imageupload\resources\views/employees/create.blade.php ENDPATH**/ ?>