@extends('employees.layout')
@section('content')
<div class="card" style="margin: 20px;">
<div class="card-header">Create New Employee</div>
<div class="card-body">
<form action="{{ url('employee') }}" method="post"
enctype="multipart/form-data">
{!! csrf_field() !!}
<label>Name</label></br>
<input type="text" name="name" id="name" class="formcontrol"></br>
<label>Gender</label></br>
<input type="text" name="Gender" id="Gender" class="formcontrol"></br>
<label>Index</label></br>
<input type="text" name="Index" id="Index" class="formcontrol"></br>
<label>Special</label></br>
<input type="text" name="Special" id="Special" class="formcontrol"></br>
<input class="form-control" name="photo" type="file" id="photo">
<input type="submit" value="Save" class="btn btn-success"></br>
</form>
</div>
</div>
@stop
